# Wallabid Android — production source

Este paquete sustituye la demo HTML. Es una base móvil real en React Native/Expo con backend Supabase preparado.

Incluye:
- navegación nativa de 5 pestañas;
- catálogo real desde base de datos;
- publicación real;
- favoritos;
- ficha de producto;
- puja transaccional validada en servidor;
- esquema de perfiles, anuncios, favoritos, pujas, conversaciones y mensajes;
- RLS;
- configuración EAS para APK interno y AAB de Google Play;
- package Android `com.wallabid.app`.

Backend Wallabid creado y separado de EU Product Radar.
El esquema inicial y las políticas RLS ya se han aplicado y la configuración pública del cliente está incluida.

Para compilar:
1. `npm install`
2. `npm run typecheck`
3. `eas build -p android --profile preview`

Para Google Play:
`eas build -p android --profile production`.

No introducir nunca una service-role/secret key en la aplicación móvil.
